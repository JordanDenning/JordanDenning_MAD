package com.example.jordandenning.mad_final;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {

    private CustomClass suggestedPizzaPlace = new CustomClass();
    Integer info = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button2);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                pizzaPlace(view);
            }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void findPizza(View view)
    {
        ToggleButton toggle = findViewById(R.id.toggleButton);
        boolean sauce = toggle.isChecked();

        //spinner
        Spinner size = findViewById(R.id.spinner);
        String pizzaSize = String.valueOf(size.getSelectedItem());

        //radio buttons
        RadioGroup crustGroup = findViewById(R.id.radioGroup);
        int crust = crustGroup.getCheckedRadioButtonId();

        //check boxes
        CheckBox peppCheckbox = findViewById(R.id.checkBox);
        Boolean pepperoni = peppCheckbox.isChecked();

        CheckBox onionsCheckBox = findViewById(R.id.checkBox2);
        Boolean onions = onionsCheckBox.isChecked();

        CheckBox shroomsCheckBox = findViewById(R.id.checkBox3);
        Boolean mushrooms = shroomsCheckBox.isChecked();

        CheckBox sausageCheckBox = findViewById(R.id.checkBox4);
        Boolean sausage = sausageCheckBox.isChecked();

        EditText pizzaName = findViewById(R.id.editText);
        String pizza = pizzaName.getText().toString();

        Switch glutenSwitch = findViewById(R.id.switch1);
        Boolean gluten = glutenSwitch.isChecked();


        //pick sport
        String pizzaString;
        String sauceString;
        String glutenString;
        String toppings = " ";
        String crustString = "";


        TextView perfectPizza = findViewById(R.id.textView3);

        if (crust == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a crust type.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {
            if(crust == R.id.radioButton1)
            {
                crustString = "thin";
                info = 0;
            }
            else if(crust == R.id.radioButton2)
            {
                crustString = "thick";
                info = 1;
            }
            if(sauce)
            {
                sauceString = "red";
            }
            else
            {
                sauceString = "white";
            }
            if(gluten)
            {
                glutenString = "is gluten free";
                info = 2;
            }
            else
            {

                glutenString = "is not gluten free";
            }
            if(pepperoni)
            {
                toppings += "pepperoni ";
            }
            if(mushrooms)
            {
                toppings +="mushroom ";
            }
            if(onions)
            {
                toppings += "onions ";
            }
            if(sausage)
            {
                toppings += "sausage ";
            }
            else if(!pepperoni && !mushrooms && !onions)
            {
                toppings = "no toppings";
            }

            pizzaString = "Your " + pizzaSize + " " + pizza + " pizza has a " + crustString + " crust with " + sauceString + " sauce, "  + glutenString + " and has " + toppings + ".";
            perfectPizza.setText(pizzaString);


        }
    }

    public void pizzaPlace(View view){

        RadioGroup crustGroup = findViewById(R.id.radioGroup);
        int crust = crustGroup.getCheckedRadioButtonId();

        Switch glutenSwitch = findViewById(R.id.switch1);
        Boolean gluten = glutenSwitch.isChecked();

        if(crust == R.id.radioButton1)
        {
            info = 0;
        }
        else if(crust == R.id.radioButton2)
        {
            info = 1;
        }
        if(gluten)
        {
            info = 2;
        }

        suggestedPizzaPlace.setPizzaPlace(info);

        String newPizzaPlace = suggestedPizzaPlace.getPizzaPlace();
        //get URL of suggested coffee shop
        String newPizzaURL = suggestedPizzaPlace.getPizzaURL();
        Log.i("shop", newPizzaPlace);
        Log.i("url", newPizzaURL);

        //create an Intent
        Intent intent = new Intent(this, Pizza.class);

//        pass data
        intent.putExtra("pizzaPlace", newPizzaPlace);
        intent.putExtra("pizzaURL", newPizzaURL);

        //start intent
        startActivity(intent);

    }
}
