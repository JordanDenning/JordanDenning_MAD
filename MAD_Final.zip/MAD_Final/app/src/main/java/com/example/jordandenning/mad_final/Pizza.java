package com.example.jordandenning.mad_final;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Pizza extends Activity {


     String pizzaPlace;
     String pizzaURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza);

        Intent intent = getIntent();
        pizzaPlace = intent.getStringExtra("pizzaPlace");
        pizzaURL = intent.getStringExtra("pizzaURL");
        Log.i("shop received", pizzaPlace);
        Log.i("url received", pizzaURL);

        TextView messageView = findViewById(R.id.textView4);
        messageView.setText( "You should check out " + pizzaPlace);


    }
}
