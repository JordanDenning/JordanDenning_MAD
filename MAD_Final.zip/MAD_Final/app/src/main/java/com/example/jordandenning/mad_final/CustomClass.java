package com.example.jordandenning.mad_final;

import java.util.Locale;

public class CustomClass {
    private String pizzaPlace;
    private String pizzaURL;

    private void setPizzaInfo(Integer info){
        switch (info){
            case 0: //thin
                pizzaPlace="Pizzeria Locale";
                pizzaURL="https://localeboulder.com/";
                break;
            case 1: //thick
                pizzaPlace="Backcountry Pizza";
                pizzaURL="https://backcountrypizzaandtaphouse.info/";
                break;
            case 2: //GF
                pizzaPlace="Boss Lady";
                pizzaURL="https://bossladypizza.com/";
                break;
            default:
                pizzaPlace="Dominos";
                pizzaURL="https://www.dominos.com/en/";
        }
    }

    public void setPizzaPlace(Integer info){

        setPizzaInfo(info);
    }

    public void setPizzaUrl(Integer info){

        setPizzaInfo(info);
    }

    public String getPizzaPlace(){

        return pizzaPlace;
    }

    public String getPizzaURL(){

        return pizzaURL;
    }
}
