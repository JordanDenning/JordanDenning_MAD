package com.example.jordandenning.lab6proto;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView.OnItemSelectedListener;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
//https://www.bing.com/videos/search?q=add+action+bar+icons+android&&view=detail&mid=8B0C521B76538E498C718B0C521B76538E498C71&&FORM=VRDGAR
    //adding button to action bar
    String[] aisle;
    String[] items;
    String[] aisleImg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
           // }
      //  });



        aisle = getResources().getStringArray(R.array.aisleNumber);
        items = getResources().getStringArray(R.array.groceryItems);
        Spinner grocerySpinner = (Spinner) findViewById(R.id.spinner);

        final int[] imagesrc = new int[6];
        imagesrc[0] = R.drawable.aisle1;
        imagesrc[1] = R.drawable.aisle2;
        imagesrc[2] = R.drawable.aisle3;
        imagesrc[3] = R.drawable.aisle4;
        imagesrc[4] = R.drawable.aisle5;
        imagesrc[5] = R.drawable.aisle6;

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);

        grocerySpinner.setAdapter(adapter);
        grocerySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int index = parent.getSelectedItemPosition();
                TextView aisleMessage = findViewById(R.id.textView5);
                String message = "Aisle " + aisle[index];
                aisleMessage.setText(message);

//https://stackoverflow.com/questions/5760751/android-variable-passed-for-r-drawable-variablevalue
                ImageView aisleMap = findViewById(R.id.imageView);
                aisleMap.setImageResource(imagesrc[index]);

                //Toast.makeText(getBaseContext(), "The item is in Aisle : " + aisle[index], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.create)
        {
            Intent explicitIntent = new Intent(this, createList.class);
            startActivity(explicitIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}
