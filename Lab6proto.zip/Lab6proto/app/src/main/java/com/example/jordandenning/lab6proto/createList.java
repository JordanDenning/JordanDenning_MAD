package com.example.jordandenning.lab6proto;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

public class createList extends AppCompatActivity {

    private ListView mShoppingList;

    String[] aisleA;
    String[] itemsA;
    String[] listCreation;
    private ArrayAdapter<String> mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent receiveIntent = getIntent();

        mShoppingList = (ListView) findViewById(R.id.listView);
        listCreation = getResources().getStringArray(R.array.listItems);
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        mShoppingList.setAdapter(mAdapter);

        aisleA = getResources().getStringArray(R.array.aisleNumber);
        itemsA = getResources().getStringArray(R.array.groceryItems);
        Spinner grocerySpinner = (Spinner) findViewById(R.id.spinner2);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, itemsA);

        grocerySpinner.setAdapter(adapter);
        grocerySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int index = parent.getSelectedItemPosition();
                String item = itemsA[index];
                String aisleNumber = aisleA[index];
                String message = aisleNumber + "\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t" + item ;
                mAdapter.add(message);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

}
