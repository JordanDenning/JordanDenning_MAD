package com.example.jordandenning.lab6;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findThing(View view) {
        Spinner spinnerChoices = findViewById(R.id.spinner);
        String spinnerItem = String.valueOf(spinnerChoices.getSelectedItem());


        //radio
        RadioGroup animal = findViewById(R.id.radioGroup);
        int animal_id = animal.getCheckedRadioButtonId();

        //toggle
        ToggleButton toggle = findViewById(R.id.toggleButton);
        boolean gender = toggle.isChecked();

        TextView output = findViewById(R.id.textView);
        ImageView character = findViewById(R.id.imageView);

        EditText nameValue = findViewById(R.id.editText);
        String name = nameValue.getText().toString();

        String message;

        if(name.equals(""))
        {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please enter your name.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {

            if (gender) {
                //boy
                if (animal_id == R.id.radioButton && spinnerItem.equals("Earth")) {
                    character.setImageResource(R.drawable.smith);
                    message = "Congrats, " + name + " you're John Smith!";
                } else if (animal_id == R.id.radioButton2 && spinnerItem.equals("Water")) {
                    character.setImageResource(R.drawable.eric);
                    message = "Congrats, " + name + " you're Eric!";
                } else if (animal_id == R.id.radioButton3 && spinnerItem.equals("Air")) {
                    character.setImageResource(R.drawable.aladdin);
                    message = "Congrats, " + name + " you're Aladdin!";

                } else {
                    character.setImageResource(R.drawable.shang);
                    message = "Congrats, " + name + " you're Li Shang!";

                }

            } else {
                //girl
                if (animal_id == R.id.radioButton && spinnerItem.equals("Earth")) {
                    character.setImageResource(R.drawable.pocahontas);
                    message = "Congrats, " + name + " you're Pocahontas!";
                } else if (animal_id == R.id.radioButton2 && spinnerItem.equals("Water")) {
                    character.setImageResource(R.drawable.ariel);
                    message = "Congrats, " + name + " you're Ariel!";
                } else if (animal_id == R.id.radioButton3 && spinnerItem.equals("Air")) {
                    character.setImageResource(R.drawable.jasmine);
                    message = "Congrats, " + name + " you're Jasmine!";
                } else {
                    character.setImageResource(R.drawable.mulan);
                    message = "Congrats. " + name + " you're Mulan!";

                }

            }
            output.setText(message);
        }
    }
}
