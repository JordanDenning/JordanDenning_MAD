package com.example.jordandenning.lab7;

public class Activity2 {
        private String birthStone;
        private String birthURL;
        private String imgSrc;

        private void setStoneInfo(Integer coffeeCrowd)
        {
            switch (coffeeCrowd) {
                case 0: //January
                    birthStone = "Garnet";
                    birthURL = "http://birthstonesbymonths.net/january-birthstone-garnet/";
                    imgSrc = "jan";
                    break;
                case 1: //February
                    birthStone = "Amethyst";
                    birthURL = "http://birthstonesbymonths.net/february-birthstone-amethyst/";
                    imgSrc = "feb";
                    break;
                case 2: //March
                    birthStone = "Aquamarine";
                    birthURL = "http://birthstonesbymonths.net/march-birthstone-aquamarine/";
                    imgSrc = "march";
                    break;
                case 3: //April
                    birthStone = "Diamond";
                    birthURL = "http://birthstonesbymonths.net/april-birthstone-diamond/";
                    imgSrc = "april";
                    break;
                case 4: //May
                    birthStone = "Emerald";
                    birthURL = "http://birthstonesbymonths.net/may-birthstone-emerald/";
                    imgSrc = "may";
                    break;
                case 5: //June
                    birthStone = "Pearl";
                    birthURL = "http://birthstonesbymonths.net/june-birthstone-pearl/";
                    imgSrc = "june";
                    break;
                case 6: //July
                    birthStone = "Ruby";
                    birthURL = "http://birthstonesbymonths.net/july-birthstone-ruby/";
                    imgSrc = "july";
                    break;
                case 7: //August
                    birthStone = "Peridot";
                    birthURL = "http://birthstonesbymonths.net/august-birthstone-peridot/";
                    imgSrc = "aug";
                    break;
                case 8: //September
                    birthStone = "Sapphire";
                    birthURL = "http://birthstonesbymonths.net/september-birthstone-sapphire/";
                    imgSrc = "sep";
                    break;
                case 9: //October
                    birthStone = "Opal";
                    birthURL = "http://birthstonesbymonths.net/october-birthstone-opal/";
                    imgSrc = "oct";
                    break;
                case 10: //November
                    birthStone = "Citrine";
                    birthURL = "http://birthstonesbymonths.net/november-birthstone-citrine/";
                    imgSrc = "nov";
                    break;
                case 11: //December
                    birthStone = "Blue Topaz";
                    birthURL = "http://birthstonesbymonths.net/december-birthstone-blue-topaz/";
                    imgSrc = "dec";
                    break;
                default:
                    birthStone = "Check out Birthstones";
                    birthURL = "http://birthstonesbymonths.net/birthstone-colors/";
                    imgSrc = "jan";
            }
        }
    public void setBirthStone(Integer month){

        setStoneInfo(month);
    }

    public void setZodiacURL(Integer month){

        setBirthStone(month);
    }

    public String getBirthStone(){

        return birthStone;
    }

    public String getBirthURL(){

        return birthURL;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getImgSrc() {
        return imgSrc;
    }
}
