package com.example.jordandenning.lab7;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ReceiveActivity extends AppCompatActivity {

    private String birthStone;
    private String stoneURL;
    private String source;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive);

        Intent receiveIntent = getIntent();
        birthStone = receiveIntent.getStringExtra("stoneName");
        stoneURL = receiveIntent.getStringExtra("stoneURL");
        source = receiveIntent.getStringExtra("imgSrc");

        Log.i("stone received", birthStone);
        Log.i("url received", stoneURL);
        Log.i("src received", source);

        TextView messageView = findViewById(R.id.textView2);
        messageView.setText("Your birthstone is " + birthStone);



        final ImageButton imageButton = findViewById(R.id.imageButton);
        if (source.equals("jan"))
        {
            imageButton.setImageResource(R.drawable.jan);
        }
        else if (source.equals("feb"))
        {
            imageButton.setImageResource(R.drawable.feb);
        }
        else if (source.equals("march"))
        {
            imageButton.setImageResource(R.drawable.march);
        }
        else if (source.equals("april"))
        {
            imageButton.setImageResource(R.drawable.april);
        }
        else if (source.equals("may"))
        {
            imageButton.setImageResource(R.drawable.may);
        }
        else if (source.equals("june"))
        {
            imageButton.setImageResource(R.drawable.june);
        }
        else if (source.equals("july"))
        {
            imageButton.setImageResource(R.drawable.july);
        }
        else if (source.equals("aug"))
        {
            imageButton.setImageResource(R.drawable.aug);
        }
        else if (source.equals("sep"))
        {
            imageButton.setImageResource(R.drawable.sep);
        }
        else if (source.equals("oct"))
        {
            imageButton.setImageResource(R.drawable.oct);
        }
        else if (source.equals("nov"))
        {
            imageButton.setImageResource(R.drawable.nov);
        }
        else if (source.equals("dec"))
        {
            imageButton.setImageResource(R.drawable.dec);
        }

        View.OnClickListener imgButtonClick = new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                loadWebSite(v);
            }
        };


    }

    public void loadWebSite(View view){
        Intent implicitIntent = new Intent(Intent.ACTION_VIEW);
        implicitIntent.setData(Uri.parse(stoneURL));
        startActivity(implicitIntent);
    }
}
