package com.example.jordandenning.lab6proto;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.support.v7.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class createList extends AppCompatActivity {

    ListView mShoppingList;
    String[] aisleA;
    String[] itemsA;
    ArrayList<String> list;
    ArrayAdapter<String> mAdapter;
    Spinner grocerySpinner;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putStringArrayList("lst", list);
        Log.i("hi", "going into save");
        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent receiveIntent = getIntent();
        Log.i("onBack", "Created");

        list = new ArrayList<>();
        if (savedInstanceState != null) {
            list = savedInstanceState.getStringArrayList("lst");

        }
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);



        mShoppingList = (ListView) findViewById(R.id.listView);

        mShoppingList.setAdapter(mAdapter);

        aisleA = getResources().getStringArray(R.array.aisleNumber);
        itemsA = getResources().getStringArray(R.array.groceryItems);
        grocerySpinner = (Spinner) findViewById(R.id.spinner2);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, itemsA);

        grocerySpinner.setAdapter(adapter);

        //long press to delete
        mShoppingList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder alert = new AlertDialog.Builder(createList.this);
                alert.setMessage("Are you sure you want to delete this item?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        list.remove(mAdapter.getItem(position));//where arg2 is position of item you click
                        mAdapter.notifyDataSetChanged();
                        dialog.dismiss();

                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                alert.show();

                return false;
            }
        });

    }


    public void addToList(View view) {
        int index = grocerySpinner.getSelectedItemPosition();
        String item = itemsA[index];
        String aisleNumber = aisleA[index];
        String message;
        if (index == 0) {
            Context context = getApplicationContext();
            CharSequence text = "Please Select an Item.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (aisleNumber.length() == 2) {
                message = aisleNumber + "\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t" + item;
            } else {
                message = aisleNumber + "\t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t \t" + item;
            }
            list.add(message);
            mAdapter.notifyDataSetChanged();
        }

    }

}


