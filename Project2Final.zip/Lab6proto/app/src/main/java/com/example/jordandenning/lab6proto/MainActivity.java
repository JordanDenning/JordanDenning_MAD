package com.example.jordandenning.lab6proto;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView.OnItemSelectedListener;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
//https://www.bing.com/videos/search?q=add+action+bar+icons+android&&view=detail&mid=8B0C521B76538E498C718B0C521B76538E498C71&&FORM=VRDGAR
    //adding button to action bar
    String[] aisle;
    String[] items;
    String[] aisleImg;
    ArrayList<String> list = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent receiveIntent = getIntent();
       // list = receiveIntent.getStringArrayListExtra("shoppingList");



        aisle = getResources().getStringArray(R.array.aisleNumber);
        items = getResources().getStringArray(R.array.groceryItems);
        Spinner grocerySpinner = (Spinner) findViewById(R.id.spinner);

        final int[] imagesrc = new int[29];
        imagesrc[0] = R.drawable.safeway;
        imagesrc[1] = R.drawable.item1;
        imagesrc[2] = R.drawable.item2;
        imagesrc[3] = R.drawable.item3;
        imagesrc[4] = R.drawable.item4;
        imagesrc[5] = R.drawable.item5;
        imagesrc[6] = R.drawable.item6;
        imagesrc[7] = R.drawable.item7;
        imagesrc[8] = R.drawable.item8;
        imagesrc[9] = R.drawable.item9;
        imagesrc[10] = R.drawable.item10;
        imagesrc[11] = R.drawable.item11;
        imagesrc[12] = R.drawable.item12;
        imagesrc[13] = R.drawable.item13;
        imagesrc[14] = R.drawable.item14;
        imagesrc[15] = R.drawable.item15;
        imagesrc[16] = R.drawable.item16;
        imagesrc[17] = R.drawable.item17;
        imagesrc[18] = R.drawable.item18;
        imagesrc[19] = R.drawable.item19;
        imagesrc[20] = R.drawable.item20;
        imagesrc[21] = R.drawable.item21;
        imagesrc[22] = R.drawable.item22;
        imagesrc[23] = R.drawable.item23;
        imagesrc[24] = R.drawable.item24;
        imagesrc[25] = R.drawable.item25;
        imagesrc[26] = R.drawable.item26;
        imagesrc[27] = R.drawable.item27;
        imagesrc[28] = R.drawable.item28;


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);

        grocerySpinner.setAdapter(adapter);
        grocerySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int index = parent.getSelectedItemPosition();
                TextView aisleMessage = findViewById(R.id.textView5);
                String message;
                if(index == 0)
                {
                 message = aisle[index];
                }
                else
                { message = "Aisle " + aisle[index];
                }

                aisleMessage.setText(message);

//https://stackoverflow.com/questions/5760751/android-variable-passed-for-r-drawable-variablevalue
                ImageView aisleMap = findViewById(R.id.imageView);
                aisleMap.setImageResource(imagesrc[index]);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.create)
        {
            Intent explicitIntent = new Intent(this, createList.class);
            startActivity(explicitIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}
